<template>
  <footer>
	
  </footer>
</template>

<script>
export default {
	name: 'FooterBlock',
}
</script>

<style lang="sass" scoped>
footer
	background: grey
	width: 100%
	padding: 15px
</style>