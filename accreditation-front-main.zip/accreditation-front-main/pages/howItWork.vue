<template>
  <div class="how-work container">
	<h1>КАК ЭТО РАБОТАЕТ?</h1>
	<WorkMain />
	<Team />
  </div>
</template>

<script>
export default {

}
</script>

<style lang="sass" scoped>
.how-work
	margin-top: 90px
</style>