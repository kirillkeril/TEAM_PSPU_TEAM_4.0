from fastapi import Body, FastAPI
from typing import Union
from model import Model

from pydantic import BaseModel

class Item(BaseModel):
    value: str

app = FastAPI()

model = Model()
print("serwer work")

@app.post("/")
async def read_root(r : Item):
    try:
        inp = f"Материалы аппаратура {r.value[:25]}"
        d = model.predict(inp)
        print(d['documents'])
        return {"value": {"content": d['documents']}, "answer": d['answers'][0]}
    except:
        print(f'Ошибка!!!!!!')
        return("[ошибка]")
