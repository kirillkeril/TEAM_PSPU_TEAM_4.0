
from typing import Union
import os
from haystack.document_stores import ElasticsearchDocumentStore
from haystack.utils import fetch_archive_from_http
from haystack.utils import print_documents
from haystack import Pipeline
from haystack.nodes import TextConverter, PreProcessor
from haystack.nodes import BM25Retriever
from haystack.nodes import FARMReader
from haystack import Pipeline
from pprint import pprint
from haystack.utils import print_answers
import os

class Model:
    querying_pipeline = Pipeline()
    def __init__(self) -> None:
        document_store = ElasticsearchDocumentStore(host="localhost", port = "9200", username="", password="", index="document")
        doc_dir = "./data"

        indexing_pipeline = Pipeline()
        text_converter = TextConverter()
        preprocessor = PreProcessor(
            clean_whitespace=True,
            clean_header_footer=True,
            clean_empty_lines=True,
            split_by="word",
            split_length=200,
            split_overlap=20,
            split_respect_sentence_boundary=True,
        )


        indexing_pipeline.add_node(component=text_converter, name="TextConverter", inputs=["File"])
        indexing_pipeline.add_node(component=preprocessor, name="PreProcessor", inputs=["TextConverter"])
        indexing_pipeline.add_node(component=document_store, name="DocumentStore", inputs=["PreProcessor"])
        files_to_index = [doc_dir + "/" + f for f in os.listdir(doc_dir)]
        indexing_pipeline.run_batch(file_paths=files_to_index)


        retriever = BM25Retriever(document_store=document_store)

        reader = FARMReader(model_name_or_path="cointegrated/rubert-tiny2", use_gpu=True)

    
        self.querying_pipeline.add_node(component=retriever, name="Retriever", inputs=["Query"])
        self.querying_pipeline.add_node(component=reader, name="Reader", inputs=["Retriever"])
        print(len(self.querying_pipeline.components))

    def predict(self, input):
        prediction = self.querying_pipeline.run(
            query=input, params={"Retriever": {"top_k": 2}, "Reader": {"top_k": 2}}
        )
        # for i in prediction['answers']:
        #     print(i.answer)

        # print_answers(prediction, details="all")  ## Choose from `minimum`, `medium` and `all`
        
        return prediction

