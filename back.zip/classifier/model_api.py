from fastapi import FastAPI
from model_one import predict

app = FastAPI()


@app.post("/classifier/model_request")
async def model_request(text: dict):
    prediction = predict(text['question'])
    print(prediction)
    return prediction