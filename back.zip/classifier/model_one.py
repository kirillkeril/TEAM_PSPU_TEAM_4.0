import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import numpy as np
import panda


def predict(text):
    label_texts = panda.get_cats()

    tokenizer = AutoTokenizer.from_pretrained('cointegrated/rubert-base-cased-nli-threeway')
    model = AutoModelForSequenceClassification.from_pretrained('cointegrated/rubert-base-cased-nli-threeway')

    tokens = tokenizer([text] * len(label_texts), label_texts, truncation=True, return_tensors='pt', padding=True)

    with torch.inference_mode():
        result = torch.softmax(model(**tokens.to(model.device)).logits, -1)
    proba = result[:, model.config.label2id["entailment"]].cpu().numpy()

    proba /= sum(proba)
    indices = np.argsort(proba)[::-1][:5]

    return [label_texts[i] for i in indices]
