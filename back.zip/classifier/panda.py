import pandas as pd

cat = pd.read_csv("categories.csv", sep=';')


def get_cats():
    return cat["question"].to_list()
